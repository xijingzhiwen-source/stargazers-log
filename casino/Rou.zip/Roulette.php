<!DOCTYPE html>
<html>

<head>
  <meta charset='utf-8'>
  <meta http-equiv='X-UA-Compatible' content='IE=edge'>
  <title>Roulette</title>
  <meta name='viewport' content='width=device-width, initial-scale=1'>
  <link rel='stylesheet' type='text/css' media='screen' href='Rou.css'>
  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/vue/2.1.10/vue.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/lodash.js/4.17.4/lodash.min.js"></script>
  <script src='Rou.js'></script>
  <link href="https://fonts.cdnfonts.com/css/casino" rel="stylesheet">
  <style>
    @import url('https://fonts.cdnfonts.com/css/casino');
  </style>
</head>

<body>
  <div class="down"></div>
  <!-- originally from https://codepen.io/daniandl/pen/mMQmGV -->

  <div class="roulette">
    <div class="wheel spin">
      <div class="arrow">
      </div>
      <img src="https://i.imgur.com/N01W3Ks.png">
    </div>
  </div>

  <div class="lead">SPIN!</div>



  <div class="Value">
    <form action="Roulette.php" method="POST">
      <label for="Betchip" class="question">How many Bet?</label><br>
      <input type="text" class="form-control passwordInput" id="inputPassword3" name="chips"><br>
      <button type="submit" class="Betbtn">Bet</button>
    </form>
    <div id="result" class="result">
    </div>
  </div>

  <?php
  if (!empty($_POST["email"]) && !empty($_POST["username"]) && !empty($_POST["password"])) {
    try {
      $pdo = new PDO(
        "mysql:host=localhost;dbname=casino",
        "root",
        "",
        [
          PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
          PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
          PDO::ATTR_EMULATE_PREPARES => false
        ]
      );
      $sql = "SELECT * FROM infos WHERE user_email=:user_email";

      $stmt = $pdo->prepare($sql);
      $stmt->bindValue(':user_email', $_POST["email"], PDO::PARAM_STR);

      $stmt->execute();

      $result = $stmt->fetch();

      if ($correctEmail == $_POST["email"] && $correctUsername == $_POST["username"] && $correct) {
        echo "a";
        header("Location: qrcode.php");
        exit;
      } else {
        echo "i";
      }
    } catch (Exception $e) {
      print ($e->getMessage() . "<br>");
    }
  }
  ?>
</body>

</html>