<!DOCTYPE html>
<html lang="ja">

<head>
  <meta charset="UTF-8">
  <title>Flip Card Test</title>
  <link rel='stylesheet' type='text/css' media='screen' href='Exchange.css'>
  <script src='Exchange.js'></script>
  <link href="https://fonts.cdnfonts.com/css/casino" rel="stylesheet">
  <style>
    @import url('https://fonts.cdnfonts.com/css/casino');
  </style>
</head>

<body>
  <div class="gazou"><img src="online.webp"></img></div>

  <div class="tytol">Exchange Coin</div><br>
  <div class="explain">RATE</div>

  <?php
  if (!empty($_POST["email"]) && !empty($_POST["username"]) && !empty($_POST["password"])) {
    try {
      $pdo = new PDO(
        "mysql:host=localhost;dbname=casino",
        "root",
        "",
        [
          PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
          PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
          PDO::ATTR_EMULATE_PREPARES => false
        ]
      );
      $sql = "SELECT * FROM infos WHERE user_email=:user_email";

      $stmt = $pdo->prepare($sql);
      $stmt->bindValue(':user_email', $_POST["email"], PDO::PARAM_STR);

      $stmt->execute();

      $result = $stmt->fetch();

      if ($correctEmail == $_POST["email"] && $correctUsername == $_POST["username"] && $correct) {
        echo "a";
        header("Location: qrcode.php");
        exit;
      } else {
        echo "i";
      }
    } catch (Exception $e) {
      print ($e->getMessage() . "<br>");
    }
  }
  ?>
</body>

</html>